# fitransit
 A fast tool to fit transit light curve.
